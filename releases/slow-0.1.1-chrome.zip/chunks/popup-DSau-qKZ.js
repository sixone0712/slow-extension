(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,t=document.querySelector(`#app`);t.innerHTML=`
  <div class="popup">
    <div class="brand">
      <img src="/icon/300.png" class="app-icon" alt="Slow icon" />
      <div class="logo">SLOW</div>
    </div>
    <p class="tagline">Flow is Slow!</p>
    <div class="toggle-row">
      <span class="toggle-label">Extension</span>
      <label class="switch">
        <input type="checkbox" id="toggle" />
        <span class="slider"></span>
      </label>
    </div>
    <p class="status" id="status">Loading...</p>
  </div>
`;var n=document.querySelector(`#toggle`),r=document.querySelector(`#status`);function i(e){r.textContent=e?`ON`:`OFF`,r.className=`status ${e?`on`:`off`}`}e.storage.local.get({slowEnabled:!0}).then(e=>{let t=e.slowEnabled;n.checked=t,i(t)}),n.addEventListener(`change`,async()=>{let t=n.checked;await e.storage.local.set({slowEnabled:t}),i(t);let[r]=await e.tabs.query({active:!0,currentWindow:!0});r?.id&&(await e.scripting.executeScript({target:{tabId:r.id},func:e=>{localStorage.setItem(`slowEnabled`,String(e))},args:[t]}),e.tabs.reload(r.id))});